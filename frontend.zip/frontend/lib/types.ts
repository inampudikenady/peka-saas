export type PlatformTokenResponse = { access_token: string; token_type: string };
export type TenantStatus = "active" | "suspended" | "retired";
export type Tenant = {
  id: string; slug: string; name: string; display_name: string;
  status: TenantStatus; primary_domain: string | null; subdomain: string | null;
  tenant_url: string | null; timezone: string; created_at: string; updated_at: string;
};
export type TenantCreate = {
  slug: string; name: string; display_name: string; primary_domain?: string | null;
  timezone: string; initial_admin_email: string; initial_admin_full_name: string;
};
export type TenantCreateResponse = { tenant: Tenant; admin_setup_link: string };
export type TenantMe = {
  id: string; email: string; full_name: string; auth_source: "local" | "sso"; tenant_id: string;
};
export type SSOProvider = "entra_id" | "okta" | "generic_oidc";
export type TenantSSOConfig = {
  provider: SSOProvider; issuer_url: string | null; client_id: string | null;
  authorization_endpoint: string | null; token_endpoint: string | null;
  jwks_uri: string | null; redirect_uri: string | null; scopes: string; enabled: boolean;
};
export type TenantSSOUpdate = {
  provider: SSOProvider; issuer_url: string; client_id: string;
  client_secret: string; scopes: string; enabled: boolean;
};
