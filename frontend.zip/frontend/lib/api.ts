import type { PlatformTokenResponse, Tenant, TenantCreate, TenantCreateResponse, TenantMe, TenantSSOConfig, TenantSSOUpdate } from "@/lib/types";

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const response = await fetch(path, { ...init, headers });
  if (!response.ok) {
    let message = "Something went wrong. Please try again.";
    try { const body = await response.json(); message = body.detail ?? message; } catch {}
    throw new ApiError(response.status, message);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

const TOKEN_KEY = "peka_platform_session";
export const platformSession = {
  get: () => typeof window === "undefined" ? null : sessionStorage.getItem(TOKEN_KEY),
  set: (token: string) => sessionStorage.setItem(TOKEN_KEY, token),
  clear: () => sessionStorage.removeItem(TOKEN_KEY),
};

async function platformRequest<T>(path: string, init: RequestInit = {}) {
  const token = platformSession.get();
  const headers = new Headers(init.headers);
  if (token) headers.set("Authorization", `Bearer ${token}`);
  try { return await request<T>(path, { ...init, headers }); }
  catch (error) { if (error instanceof ApiError && error.status === 401) platformSession.clear(); throw error; }
}

const tenantBase = (slug: string) => `/t/${encodeURIComponent(slug)}/api/v1/tenant`;

export const platformApi = {
  login: (body: { username: string; password: string }) => request<PlatformTokenResponse>("/api/v1/platform/auth/login", { method: "POST", body: JSON.stringify(body) }),
  tenants: () => platformRequest<Tenant[]>("/api/v1/platform/tenants"),
  createTenant: (body: TenantCreate) => platformRequest<TenantCreateResponse>("/api/v1/platform/tenants", { method: "POST", body: JSON.stringify(body) }),
};

export const tenantApi = {
  activate: (slug: string, body: { token: string; password: string }) => request<{ authenticated: boolean }>(`${tenantBase(slug)}/auth/activate`, { method: "POST", credentials: "include", body: JSON.stringify(body) }),
  localLogin: (slug: string, body: { username: string; password: string }) => request<{ authenticated: boolean }>(`${tenantBase(slug)}/auth/local-login`, { method: "POST", credentials: "include", body: JSON.stringify(body) }),
  me: (slug: string) => request<TenantMe>(`${tenantBase(slug)}/auth/me`, { credentials: "include" }),
  logout: (slug: string) => request<void>(`${tenantBase(slug)}/auth/logout`, { method: "POST", credentials: "include" }),
  getSSO: (slug: string) => request<TenantSSOConfig>(`${tenantBase(slug)}/admin/security/sso`, { credentials: "include" }),
  updateSSO: (slug: string, body: TenantSSOUpdate) => request<TenantSSOConfig>(`${tenantBase(slug)}/admin/security/sso`, { method: "PUT", credentials: "include", body: JSON.stringify(body) }),
};
