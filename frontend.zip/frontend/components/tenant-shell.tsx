"use client";
import { useRouter } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { tenantApi } from "@/lib/api";
import type { TenantMe } from "@/lib/types";
export function TenantShell({ slug, user, children, title }: { slug: string; user: TenantMe; children: React.ReactNode; title: string }) { const router = useRouter(); return <AppShell title={title} subtitle={`${slug} tenant workspace`} userLabel={user.full_name} items={[{ label: "Dashboard", href: `/t/${slug}/app` }, { label: "SSO security", href: `/t/${slug}/admin/security/sso` }]} onLogout={async () => { try { await tenantApi.logout(slug); } finally { router.replace(`/t/${slug}/login`); } }}>{children}</AppShell>; }
