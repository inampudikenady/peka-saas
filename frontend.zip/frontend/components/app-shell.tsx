"use client";
import Link from "next/link";
import { Menu, ShieldCheck, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export type NavItem = { label: string; href: string };
export function AppShell({ title, subtitle, items, children, userLabel, onLogout }: { title: string; subtitle: string; items: NavItem[]; children: ReactNode; userLabel: string; onLogout: () => void }) {
  const [open, setOpen] = useState(false);
  return <div className="min-h-screen bg-slate-50 text-slate-900"><aside className={cn("fixed inset-y-0 left-0 z-30 w-64 border-r border-slate-200 bg-slate-950 p-5 text-white transition-transform md:translate-x-0", open ? "translate-x-0" : "-translate-x-full")}><div className="mb-10 flex items-center justify-between"><div className="flex items-center gap-2 font-semibold"><ShieldCheck className="h-6 w-6 text-blue-400"/> PEKA</div><button className="md:hidden" onClick={() => setOpen(false)} aria-label="Close navigation"><X/></button></div><nav className="space-y-1">{items.map(item => <Link key={item.href} href={item.href} className="block rounded-md px-3 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-white" onClick={() => setOpen(false)}>{item.label}</Link>)}</nav></aside>{open && <button aria-label="Close navigation overlay" className="fixed inset-0 z-20 bg-black/30 md:hidden" onClick={() => setOpen(false)}/>}<div className="md:pl-64"><header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur sm:px-8"><div className="flex items-center gap-3"><button className="md:hidden" onClick={() => setOpen(true)} aria-label="Open navigation"><Menu/></button><div><h1 className="font-semibold">{title}</h1><p className="hidden text-xs text-slate-500 sm:block">{subtitle}</p></div></div><div className="flex items-center gap-3"><span className="hidden text-sm text-slate-600 sm:inline">{userLabel}</span><Button variant="ghost" onClick={onLogout}>Log out</Button></div></header><main className="p-4 sm:p-8">{children}</main></div></div>;
}
