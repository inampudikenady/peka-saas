"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { platformSession } from "@/lib/api";
export function PlatformShell({ children, title }: { children: React.ReactNode; title: string }) { const router = useRouter(); const [ready, setReady] = useState(false); useEffect(() => { if (!platformSession.get()) router.replace("/platform/login"); else setReady(true); }, [router]); if (!ready) return <main className="p-8 text-sm text-slate-500">Checking your session…</main>; return <AppShell title={title} subtitle="Platform administration" userLabel="Platform administrator" items={[{ label: "Dashboard", href: "/platform/dashboard" }, { label: "Tenants", href: "/platform/tenants" }, { label: "Create tenant", href: "/platform/tenants/new" }]} onLogout={() => { platformSession.clear(); router.replace("/platform/login"); }}>{children}</AppShell>; }
