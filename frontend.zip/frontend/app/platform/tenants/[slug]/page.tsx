"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { PlatformShell } from "@/components/platform-shell";
import { Card } from "@/components/ui/card";
export default function TenantDetailPlaceholder() { const { slug } = useParams<{ slug: string }>(); return <PlatformShell title="Tenant detail"><Card className="p-8"><h2 className="text-xl font-semibold">{slug}</h2><p className="mt-2 text-sm text-slate-500">Detailed tenant operations will be added in a later phase.</p><Link className="mt-5 inline-block text-sm font-medium text-blue-600 hover:underline" href="/platform/tenants">Back to tenants</Link></Card></PlatformShell>; }
