"use client";
import { PlatformShell } from "@/components/platform-shell";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
const metrics = [["Active tenants", "—"], ["Users", "—"], ["Service health", "Operational"]];
export default function PlatformDashboard() { return <PlatformShell title="Dashboard"><div className="mb-8"><h2 className="text-2xl font-semibold">Platform overview</h2><p className="mt-1 text-sm text-slate-500">A high-level view of PEKA operations.</p></div><div className="grid gap-4 md:grid-cols-3">{metrics.map(([label, value]) => <Card key={label}><CardHeader><p className="text-sm text-slate-500">{label}</p></CardHeader><CardContent><p className="text-2xl font-semibold">{value}</p></CardContent></Card>)}</div></PlatformShell>; }
